import React, { useState, useEffect } from "react";
import GoogleMapReact from "google-map-react";
import NavToAll from "../component/NavToAll";


const locationsConfig = {
  Downtown: {
    center: { lat: 25.2048, lng: 55.2744 },
    zoom: 15,
    locations: [
      { lat: 25.1972, lng: 55.2744, text: "Burj Khalifa" },
      { lat: 25.1985, lng: 55.2796, text: "Dubai Mall" },
      { lat: 25.1934, lng: 55.2689, text: "Dubai Opera" },
      { lat: 25.1927, lng: 55.2799, text: "The Address Downtown Dubai" },
    ],
  },
  Marina: {
    center: { lat: 25.0773, lng: 55.1358 },
    zoom: 15,
    locations: [
      { lat: 25.0866, lng: 55.1467, text: "Cayan Tower" },
      { lat: 25.0895, lng: 55.1471, text: "Marina Torch" },
      { lat: 25.0898, lng: 55.1476, text: "Princess Tower" },
      { lat: 25.0743, lng: 55.1423, text: "Almas Tower" },
    ],
  },
  Palm_Jumeirah: {
    center: { lat: 25.1120, lng: 55.1390 },
    zoom: 15,
    locations: [
      { lat: 25.1304, lng: 55.1175, text: "Atlantis The Palm" },
      { lat: 25.1115, lng: 55.1390, text: "The Palm Tower" },
      { lat: 25.1092, lng: 55.1386, text: "Dukes The Palm" },
      { lat: 25.1301, lng: 55.1564, text: "Waldorf Astoria Dubai Palm Jumeirah" },
    ],
  },
  Deira: {
    center: { lat: 25.2684, lng: 55.3093 },
    zoom: 15,
    locations: [
      { lat: 25.2644, lng: 55.3160, text: "Deira Clocktower" },
      { lat: 25.2668, lng: 55.3165, text: "Al Ghurair Centre" },
      { lat: 25.2876, lng: 55.3134, text: "Hyatt Regency Dubai" },
      { lat: 25.2530, lng: 55.3341, text: "Deira City Centre" },
    ],
  },
  Business_Bay: {
    center: { lat: 25.1847, lng: 55.2652 },
    zoom: 15,
    locations: [
      { lat: 25.1851, lng: 55.2587, text: "JW Marriott Marquis Dubai" },
      { lat: 25.1864, lng: 55.2611, text: "The Oberoi Dubai" },
      { lat: 25.1858, lng: 55.2617, text: "Paramount Hotel Dubai" },
      { lat: 25.1867, lng: 55.2609, text: "Bay Square" },
    ],
  },
};

const SimpleMap = () => {
  const [mapInstance, setMapInstance] = useState(null);
  const [mapsInstance, setMapsInstance] = useState(null);
  const [hoveredLocation, setHoveredLocation] = useState(null);
  const [clickedLocation, setClickedLocation] = useState(null); // Track clicked marker
  const [activeCountry, setActiveCountry] = useState(null);
  const [mapBounds, setMapBounds] = useState(null);

  useEffect(() => {
    if (mapInstance && mapsInstance) {
      renderMarkers();
    }
  }, [activeCountry, mapInstance, mapsInstance]);

  useEffect(() => {
    if (mapInstance && mapsInstance) {
      renderDefaultMarkers();
      mapInstance.addListener("bounds_changed", () => {
        setMapBounds(mapInstance.getBounds());
      });
    }
  }, [mapInstance, mapsInstance]);

  const handleCountryClick = (country) => {
    setActiveCountry(country);
    mapInstance.setCenter(locationsConfig[country].center);
    mapInstance.setZoom(locationsConfig[country].zoom);
  };

  const renderMarkers = () => {
    if (!mapInstance || !mapsInstance || !activeCountry) return;

    const locations = locationsConfig[activeCountry].locations;

    locations.forEach(({ lat, lng, text }) => {
      const marker = new mapsInstance.Marker({
        position: { lat, lng },
        map: mapInstance,
        title: text,
      });

      marker.addListener("mouseover", () => {
        setHoveredLocation(text);
      });

      marker.addListener("mouseout", () => {
        setHoveredLocation(null);
      });

      marker.addListener("click", () => {
        setClickedLocation({ lat, lng, text });
      });
    });
  };

  const renderDefaultMarkers = () => {
    if (!mapInstance || !mapsInstance) return;

    Object.keys(locationsConfig).forEach((country) => {
      const { center, locations } = locationsConfig[country];
      const marker = new mapsInstance.Marker({
        position: center,
        map: mapInstance,
        title: `${country} (${locations.length} properties)`,
      });

      marker.addListener("mouseover", () => {
        setHoveredLocation(`${country} (${locations.length} properties)`);
      });

      marker.addListener("mouseout", () => {
        setHoveredLocation(null);
      });

      marker.addListener("click", () => {
        setClickedLocation({ lat: center.lat, lng: center.lng, text: `${country} (${locations.length} properties)` });
      });
    });
  };

  const getPixelPosition = (lat, lng) => {
    if (!mapBounds || !mapInstance || !mapsInstance) return { x: 0, y: 0 };

    const scale = Math.pow(2, mapInstance.getZoom());
    const nw = mapBounds.getNorthEast();
    const se = mapBounds.getSouthWest();
    const worldCoordinateNW = mapInstance.getProjection().fromLatLngToPoint(new mapsInstance.LatLng(nw.lat(), se.lng()));
    const worldCoordinate = mapInstance.getProjection().fromLatLngToPoint(new mapsInstance.LatLng(lat, lng));
    const pixelOffset = new mapsInstance.Point(
      Math.floor((worldCoordinate.x - worldCoordinateNW.x) * scale),
      Math.floor((worldCoordinate.y - worldCoordinateNW.y) * scale)
    );

    return {
      x: pixelOffset.x,
      y: pixelOffset.y,
    };
  };

  const defaultProps = {
    center: { lat: 25.2048, lng: 55.2744 },
    zoom: 12,
  };

  return (
    <div>
      <div style={{ height: "100vh", width: "100%", position: "relative" }}>
        <GoogleMapReact
          bootstrapURLKeys={{ key: "AIzaSyCXENRI6QU3NowjVqVzhP_2Tv6IyUXVjPc" }} // Replace with your Google Maps API key
          defaultCenter={defaultProps.center}
          defaultZoom={defaultProps.zoom}
          yesIWantToUseGoogleMapApiInternals
          onGoogleApiLoaded={({ map, maps }) => {
            setMapInstance(map);
            setMapsInstance(maps);
          }}
        />
        {clickedLocation && (
          <div
            style={{
              position: "absolute",
              top: "10px",
              left: "50%",
              transform: "translateX(-50%)",
              backgroundColor: "white",
              padding: "10px",
              borderRadius: "5px",
              boxShadow: "0 0 5px rgba(0, 0, 0, 0.3)",
              zIndex: 1000,
            }}
          >
            <h4>{clickedLocation.text}</h4>
            <img src="property_image_url" alt="Property" style={{ width: "100%" }} /> {/* Replace with actual property image URL */}
            <button>Call Now</button>
          </div>
        )}
        {Object.keys(locationsConfig).map((country) => {
          const { lat, lng } = locationsConfig[country].center;
          const { x, y } = getPixelPosition(lat, lng);
          return (
            <button
              className="round-button"
              key={country}
              style={{
                position: "absolute",
                top: y,
                left: x,
                transform: "translate(-50%, -50%)",
                cursor: "pointer",
                backgroundColor: "#052c65",
                padding: "15px",
                borderRadius: "100%",
                boxShadow: "0 0 10px rgba(0, 0, 0, 0.3)",
                border: "2px solid white",
                color: "white",
                fontSize: "16px",
              }}
              onClick={() => handleCountryClick(country)}
            >
              {locationsConfig[country].locations.length}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default SimpleMap;
